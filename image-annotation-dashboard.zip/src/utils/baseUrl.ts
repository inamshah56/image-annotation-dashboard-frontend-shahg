export const baseUrl = "https://agronomics.pk/image-annotation-dashboard";
// export const baseUrl = "http://192.168.100.17:8093"
// export const baseUrl = "http://192.168.200.174:8093"