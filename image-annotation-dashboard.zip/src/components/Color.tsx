import { FC } from "react";

const Color: FC<ColorProp> = ({color}) => {
  return <div>Color</div>;
};

export default Color;
